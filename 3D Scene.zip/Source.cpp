#include <iostream>
#include <GL/glew.h>
#include <GLFW/glfw3.h>
#include <learnOpengl/camera.h>
#include <vector>

#define STB_IMAGE_IMPLEMENTATION 
#include <stb_image.h>


/* GLM Math Headers  /
/  ---------------- */
#include <glm/glm.hpp>
#include <glm/gtx/transform.hpp>
#include <glm/gtc/type_ptr.hpp>



using namespace glm;
using namespace std;


/*Shader program Macro*/
#ifndef GLSL
#define GLSL(Version, Source) "#version " #Version " core \n" #Source
#endif


/* Unnamed namespace for settings  /
/  ------------------------------ */
namespace {
	const char* const WINDOW_TITLE = "3D Scene"; // Window title 

	const int WINDOW_WIDTH = 800;
	const int WINDOW_HEIGHT = 600;

	/* Stores GL data relative to given mesh  /
	/  ------------------------------------- */
	struct GLMesh {
		// For book pages
		GLuint VAO, VBO, nVertices;
		// For Book Cover
		GLuint bcVAO, bcVBO, nBookCoverVertices;
		// For sticky pads plane
		GLuint spVAO, spVBO, nStickyPlaneVertices;
		// For sticky pads
		GLuint sVAO, sVBO, nStickyVertices;
		// For highlighter
		GLuint hVAO, hVBO, nHighlighterVertices;
		// For paper weight
		GLuint pwVAO, pwVBO, nPaperWeightVertices;
		// For desk plane	
		GLuint pVAO, pVBO, nPlaneVertices;
		// For lights
		GLuint cVBO, cVAO, nCubeVertices;

	};

	GLFWwindow* gWindow = nullptr;	// Main window
	GLMesh gMesh;					// Triangle mesh data

	// textures
	GLuint bcTextureId, bpTextureId, spTextureId, sTextureId, hTextureId, h2TextureId, pwTextureId, pTextureId;


	vec2 gUVScale(1.0f, 1.0f);
	GLint gTexWrapMode = GL_REPEAT;

	// Shader programs
	GLuint gProgramId;
	GLuint gPlaneId;
	GLuint gFillProgramId;
	GLuint gLampProgramId;

	// camera
	Camera gCamera(glm::vec3(0.0f, 0.0f, 3.0f));
	float gLastX = WINDOW_WIDTH / 2.0f;
	float gLastY = WINDOW_HEIGHT / 2.0f;
	bool gFirstMouse = true;

	// timing
	float gDeltaTime = 0.0f; // Time between currrent frame and last frame
	float gLastFrame = 0.0f;

	// Object
	vec3 gObjectColor(1.0f, 0.0f, 0.0f);
	vec3 gObjectPosition(0.0f, 0.0f, 0.0f);
	vec3 gObjectScale(2.0f);

	// Cylinder
	vec3 gCylinderPosition(0.0f, 0.0f, 0.0f);
	vec3 gCylinderScale(0.5f, 0.5f, 0.5f);

	// Desk Plane
	vec3 gPlanePosition(0.0f, 0.0f, 0.0f);
	vec3 gPlaneScale(2.0f);

	// Stick Pads
	vec3 gStickyPosition(0.0f, 0.0f, 0.0f);
	vec3 gStickyScale(1.0f);

	// Sphere
	vec3 gSpherePosition(0.2f, 0.0f, -0.2f);
	vec3 gSphereColor(0.0f, 0.0f, 1.0f);
	vec3 gSphereScale(1.0f);

	// Light
	vec3 gLightColor(1.0f, 1.0f, 1.0f);
	vec3 gLightPosition(-2.0f, 2.5f, 0.0f);
	vec3 gLightScale(0.1f);

	// Fill Light
	vec3 gFillColor(1.0f, 0.5f, 0.5f);
	vec3 gFillPosition(5.0f, 0.7f, -2.0f);
	vec3 gFillScale(0.1f);

	bool perspectiveView = true;
}




/* ---- Vertex Shader Source Code ---- */
const GLchar* vertexShaderSource = GLSL(440,

	layout(location = 0) in vec3 position;			// VertexAttrib Pointer 0
layout(location = 1) in vec3 normal;			// VertexAttrib Pointer 1
layout(location = 2) in vec2 textureCoordinate; // VertexAttrib Pointer 2

out vec3 vertexNormal;				// outgoing normal data
out vec3 vertexFragmentPos;			// outgoing color data
out vec2 vertexTextureCoordinate;	// outgoing texture data

// Global variables for the  transform matrices
uniform mat4 model;
uniform mat4 view;
uniform mat4 projection;

void main()
{
	gl_Position = projection * view * model * vec4(position, 1.0f);	// Transform vertices to clip coordinates

	vertexFragmentPos = vec3(model * vec4(position, 1.0f));			// Get fragtment position in world space

	vertexNormal = mat3(transpose(inverse(model))) * normal;		// Get normal vectors in world space
	vertexTextureCoordinate = textureCoordinate;
}
);


/* ---- Fragment Shader Source Code ---- */
const GLchar* fragmentShaderSource = GLSL(440,

	in vec3 vertexNormal;			 // incoming color data
in vec3 vertexFragmentPos;		 // incoming normals
in vec2 vertexTextureCoordinate; // inoming texture data

out vec4 fragmentColor;			 // outgoing color
out vec4 fillFragmentColor;

// Uniform / Global variables for object color, light color, light position, and camera/view position
uniform vec3 objectColor;
uniform vec3 lightColor;
uniform vec3 lightPos;
uniform vec3 fillColor;
uniform vec3 fillPos;
uniform vec3 viewPosition;
uniform sampler2D uTexture;
uniform vec2 uvScale;

void main()
{
	/*---- Phong lighting model calculations to generate ambient, diffuse, and specular components ---- */
	// -------------------------------------------------------------------------------------------------//
	float ambientStrength = 0.2f;														// Set ambient light strength
	vec3 ambient = ambientStrength * lightColor;										// Gen color

	//Calculate Diffuse lighting
	vec3 norm = normalize(vertexNormal);												// Normalize vector
	vec3 lightDirection = normalize(lightPos - vertexFragmentPos);						// Calc light direction
	float impact = max(dot(norm, lightDirection), 0.0);									// Calc diffuse impact
	vec3 diffuse = impact * lightColor;													// Generate diffuse light color

	//Calculate Specular lighting
	float specularIntensity = 5.0f;														// Set specular light strength
	float highlightSize = 40.0f;														// Set highlight size
	vec3 viewDir = normalize(viewPosition - vertexFragmentPos);							// Calc light direction
	vec3 reflectDir = reflect(-lightDirection, norm);									// Calc reflection vector
	//Calculate specular component
	float specularComponent = pow(max(dot(viewDir, reflectDir), 0.0), highlightSize);
	vec3 specular = specularIntensity * specularComponent * lightColor;


	// ----------- Fill Lighting ----------- //
	// -- Repeat above, but for fill ------- //

	// Calculate AmbientLighting
	float fillAmbientStrength = 0.10f;
	vec3 fillAmbient = fillAmbientStrength * fillColor;

	//Calculate Diffuse lighting*/

	vec3 fillDirection = normalize(fillPos - vertexFragmentPos);
	float fillImpact = max(dot(norm, fillDirection), 0.0);
	vec3 fillDiffuse = fillImpact * fillColor;

	//Calculate Specular lighting*/
	float fillSpecularIntensity = 0.10f;
	float fillHighlightSize = 10.0f;
	vec3 fillViewDir = normalize(viewPosition - vertexFragmentPos);
	vec3 fillReflectDir = reflect(-fillDirection, norm);
	//Calculate specular component
	float fillSpecularComponent = pow(max(dot(fillViewDir, fillReflectDir), 0.0), fillHighlightSize);
	vec3 fillSpecular = fillSpecularIntensity * fillSpecularComponent * fillColor;

	// Texture holds the color to be used for all three components
	vec3 objectColor = texture(uTexture, vertexTextureCoordinate).xyz;
	vec3 keyResult = (ambient + diffuse + specular);
	vec3 fillResult = (fillAmbient + fillDiffuse + fillSpecular);
	vec3 lightingResult = keyResult + fillResult;
	vec3 phong = (lightingResult)*objectColor;


	fragmentColor = vec4(phong, 1.0f);
}
);


/* ------- Lamp Vertex Shader Source Code ------- */
const GLchar* lampVertexShaderSource = GLSL(440,

	layout(location = 0) in vec3 position; // Vertex attrib 0

		//Global variables for the  transform matrices
uniform mat4 model;
uniform mat4 view;
uniform mat4 projection;

void main()
{
	gl_Position = projection * view * model * vec4(position, 1.0f);  // Transforms vertices into clip coordinates
}
);


/* ------- Lamp Fragment Shader Source Code ------- */
const GLchar* lampFragmentShaderSource = GLSL(440,

	out vec4 fragmentColor; // Vertex attrib 0

void main()
{
	fragmentColor = vec4(1.0f);  // color
}
);

/* ------- FIll Vertex Shader Source ------- */
const GLchar* fillVertexShaderSource = GLSL(440,

	layout(location = 0) in vec3 position;  // Vertex atrrib 0

//Global variables for the  transform matrices
uniform mat4 model;
uniform mat4 view;
uniform mat4 projection;

void main()
{
	gl_Position = projection * view * model * vec4(position, 1.0f); // Transforms vertices into clip coordinates
}
);


/* ------- Fill Fragment Shader Source Code ------- */
const GLchar* fillFragmentShaderSource = GLSL(440,

	out vec4 fragmentColor;
void main()
{
	fragmentColor = vec4(1.0f);
}
);



/* Flips loaded image on the y axis  /
/  -------------------------------- */
void flipImageVertically(unsigned char* image, int width, int height, int channels)
{
	for (int j = 0; j < height / 2; ++j)
	{
		int index1 = j * width * channels;
		int index2 = (height - 1 - j) * width * channels;

		for (int i = width * channels; i > 0; --i)
		{
			unsigned char tmp = image[index1];
			image[index1] = image[index2];
			image[index2] = tmp;
			++index1;
			++index2;
		}
	}
}

/* Called whenever window is resized  /
/  --------------------------------- */
void resizeWindow(GLFWwindow* window, int width, int height) {
	glViewport(0, 0, width, height);
}

/* Called whenever mouse is moved  /
/  ------------------------------ */
void mousePositionCallback(GLFWwindow* window, double xpos, double ypos)
{
	if (gFirstMouse)
	{
		gLastX = xpos;
		gLastY = ypos;
		gFirstMouse = false;
	}

	float xoffset = xpos - gLastX;
	float yoffset = gLastY - ypos; // reversed since y-coordinates go from bottom to top

	gLastX = xpos;
	gLastY = ypos;

	gCamera.ProcessMouseMovement(xoffset, yoffset);
}

/* Called to whenever the mouse scroll wheel scrolls, /
*  changes zoom and camera speed					  /
/  ------------------------------------------------- */
void mouseScrollCallback(GLFWwindow* window, double xoffset, double yoffset) {
	gCamera.ProcessMouseScroll(yoffset);
}

/* Handle mouse button events  /
/  -------------------------- */
void mouseButtonCallback(GLFWwindow* window, int button, int action, int mods)
{
	switch (button)
	{
	case GLFW_MOUSE_BUTTON_LEFT:
	{
		if (action == GLFW_PRESS)
			cout << "Left mouse button pressed" << endl;
		else
			cout << "Left mouse button released" << endl;
	}
	break;

	case GLFW_MOUSE_BUTTON_MIDDLE:
	{
		if (action == GLFW_PRESS)
			cout << "Middle mouse button pressed" << endl;
		else
			cout << "Middle mouse button released" << endl;
	}
	break;

	case GLFW_MOUSE_BUTTON_RIGHT:
	{
		if (action == GLFW_PRESS)
			cout << "Right mouse button pressed" << endl;
		else
			cout << "Right mouse button released" << endl;
	}
	break;

	default:
		cout << "Unhandled mouse button event" << endl;
		break;
	}
}

/* Initialize libraries and create window  /
/  -------------------------------------- */
bool initialize(int argc, char* argv[], GLFWwindow** window) {

	/* GLFW: initialize and configure  /
	/  ------------------------------ */
	glfwInit();
	glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 4);
	glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 4);
	glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);

#ifdef __APPLE__
	glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GL_TRUE);
#endif

	/* GLFW: window creation  /
	/  --------------------- */
	gWindow = glfwCreateWindow(WINDOW_WIDTH, WINDOW_HEIGHT, WINDOW_TITLE, NULL, NULL);
	if (gWindow == NULL)
	{
		cout << "Failed to create GLFW window" << endl;
		glfwTerminate();
		return false;
	}
	glfwMakeContextCurrent(gWindow);
	glfwSetFramebufferSizeCallback(gWindow, resizeWindow);
	glfwSetCursorPosCallback(*window, mousePositionCallback);
	glfwSetScrollCallback(*window, mouseScrollCallback);
	glfwSetMouseButtonCallback(*window, mouseButtonCallback);
	/* GLEW: initialization  /
	/  ---------------- */
	glewExperimental = GL_TRUE;
	GLenum GlewInitResult = glewInit();

	if (GLEW_OK != GlewInitResult)
	{
		cerr << glewGetErrorString(GlewInitResult) << endl;
		return false;
	}



	cout << "INFO: OpenGL Version: " << glGetString(GL_VERSION) << endl;

	return true;
}


/* Process all input  /
/  ----------------- */
void processInput(GLFWwindow* window) {

	static const float cameraSpeed = 2.5f;

	if (glfwGetKey(window, GLFW_KEY_ESCAPE) == GLFW_PRESS)
		glfwSetWindowShouldClose(window, true);

	// Moves camera in direction deepending on which key is pressed
	if (glfwGetKey(window, GLFW_KEY_W) == GLFW_PRESS)
		gCamera.ProcessKeyboard(FORWARD, gDeltaTime);
	if (glfwGetKey(window, GLFW_KEY_S) == GLFW_PRESS)
		gCamera.ProcessKeyboard(BACKWARD, gDeltaTime);
	if (glfwGetKey(window, GLFW_KEY_A) == GLFW_PRESS)
		gCamera.ProcessKeyboard(LEFT, gDeltaTime);
	if (glfwGetKey(window, GLFW_KEY_D) == GLFW_PRESS)
		gCamera.ProcessKeyboard(RIGHT, gDeltaTime);
	if (glfwGetKey(window, GLFW_KEY_Q) == GLFW_PRESS)
		gCamera.ProcessKeyboard(UP, gDeltaTime);
	if (glfwGetKey(window, GLFW_KEY_E) == GLFW_PRESS)
		gCamera.ProcessKeyboard(DOWN, gDeltaTime);

	// Toggle orthographic and perspective view of scene
	if (glfwGetKey(window, GLFW_KEY_P) == GLFW_PRESS)
		perspectiveView = !perspectiveView;
}


/* Renders a frame  /
/  --------------- */
void render()  {



	// Enable z-depth
	glEnable(GL_DEPTH_TEST);

	// Clear the frame and z buffers
	glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	// Set the shader to be used
	glUseProgram(gProgramId);

	// Set object scale, rotation, and orientation
	mat4 scale = glm::scale(vec3(2.0f, 2.0f, 2.0f));
	mat4 rotation = rotate(radians(30.0f), glm::vec3(0.0, 1.0f, 0.0f));
	mat4 translation = translate(vec3(0.0f, 0.0f, 0.2f));

	mat4 model = translation * rotation * scale;

	// Toggle between perpestive and orthographic depending on key press
	mat4 projection;
	if (perspectiveView)
		projection = perspective(radians(gCamera.Zoom), (GLfloat)WINDOW_WIDTH / (GLfloat)WINDOW_HEIGHT, 0.1f, 100.0f);
	else
		projection = ortho(9.0f, -9.0f, -4.0f, 4.0f, -3.0f, 6.0f);

	// Transforms the camera: move the camera back (z axis)
	mat4 view = gCamera.GetViewMatrix();

	// Retrieves and passes transform matrices to the Shader program
	GLint modelLoc = glGetUniformLocation(gProgramId, "model");
	GLint viewLoc = glGetUniformLocation(gProgramId, "view");
	GLint projLoc = glGetUniformLocation(gProgramId, "projection");

	glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));
	glUniformMatrix4fv(viewLoc, 1, GL_FALSE, glm::value_ptr(view));
	glUniformMatrix4fv(projLoc, 1, GL_FALSE, glm::value_ptr(projection));

	// Reference matrix uniforms from the Object Shader program for the object color, light color, light position, and camera position
	GLint objectColorLoc = glGetUniformLocation(gProgramId, "objectColor");
	GLint lightColorLoc = glGetUniformLocation(gProgramId, "lightColor");
	GLint lightPositionLoc = glGetUniformLocation(gProgramId, "lightPos");
	GLint fillColorLoc = glGetUniformLocation(gProgramId, "fillColor");
	GLint fillPositionLoc = glGetUniformLocation(gProgramId, "fillPos");
	GLint viewPositionLoc = glGetUniformLocation(gProgramId, "viewPosition");
	// Pass color, light, and camera data to the Object Shader program's corresponding uniforms
	glUniform3f(objectColorLoc, gObjectColor.r, gObjectColor.g, gObjectColor.b);
	glUniform3f(lightColorLoc, gLightColor.r, gLightColor.g, gLightColor.b);
	glUniform3f(lightPositionLoc, gLightPosition.x, gLightPosition.y, gLightPosition.z);
	glUniform3f(fillColorLoc, gFillColor.r, gFillColor.g, gFillColor.b);
	glUniform3f(fillPositionLoc, gFillPosition.x, gFillPosition.y, gFillPosition.z);

	const glm::vec3 cameraPosition = gCamera.Position;
	glUniform3f(viewPositionLoc, cameraPosition.x, cameraPosition.y, cameraPosition.z);

	GLint UVScaleLoc = glGetUniformLocation(gProgramId, "uvScale");
	glUniform2fv(UVScaleLoc, 1, glm::value_ptr(gUVScale));

	glBindVertexArray(0);

	// ---- Draw Book Pages ---- //

	// Activate the VBOs contained within the mesh's VAO
	glBindVertexArray(gMesh.VAO);

	// bind textures on corresponding texture units
	glActiveTexture(GL_TEXTURE0);
	glBindTexture(GL_TEXTURE_2D, bpTextureId);

	// Draws the triangles
	glDrawArrays(GL_TRIANGLES, 0, gMesh.nVertices);

	glBindVertexArray(0);

	// ---- Draw Book Cover ---- //
	// Activate the VBO contained within the mesh's VAO
	glBindVertexArray(gMesh.bcVAO);

	// bind textures on corresponding texture units
	glActiveTexture(GL_TEXTURE0);
	glBindTexture(GL_TEXTURE_2D, bcTextureId);

	glDrawArrays(GL_TRIANGLES, 0, gMesh.nBookCoverVertices);

	glBindVertexArray(0);

	// ------- Draw Sticky Pad Plane ------- //
	
	// Reset model and uniform locations to match object
	model = translate(vec3(1.0f, 0.0f, -0.8f)) * rotate(radians(-30.0f), glm::vec3(0.0, 1.0f, 0.0f)) * glm::scale(vec3(2.0f, 2.0f, 1.5f));;

	modelLoc = glGetUniformLocation(gProgramId, "model");
	viewLoc = glGetUniformLocation(gProgramId, "view");
	projLoc = glGetUniformLocation(gProgramId, "projection");

	// Pass matrix data to the Shader program's matrix uniforms
	glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));
	glUniformMatrix4fv(viewLoc, 1, GL_FALSE, glm::value_ptr(view));
	glUniformMatrix4fv(projLoc, 1, GL_FALSE, glm::value_ptr(projection));

	// Activate the VBOs contained within the mesh's VAO
	glBindVertexArray(gMesh.spVAO);

	// bind textures on corresponding texture units
	glActiveTexture(GL_TEXTURE0);
	glBindTexture(GL_TEXTURE_2D, spTextureId);

	// Draws the triangles
	glDrawArrays(GL_TRIANGLES, 0, gMesh.nStickyPlaneVertices);

	glBindVertexArray(0);

	// ------- Draw Sticky Pads ------- //
	// Activate the VBOs contained within the mesh's VAO
	glBindVertexArray(gMesh.sVAO);

	// bind textures on corresponding texture units
	glActiveTexture(GL_TEXTURE0);
	glBindTexture(GL_TEXTURE_2D, sTextureId);

	// Draws the triangles
	glDrawArrays(GL_TRIANGLES, 0, gMesh.nStickyVertices);

	glBindVertexArray(0);

	// ---- Draw Highlighter Pieces ---- //
	// Main Barrel
	model = translate(vec3(1.0f, 0.0f, 0.0f)) * rotate(radians(0.0f), glm::vec3(0.0, 1.0f, 0.0f)) * glm::scale(vec3(0.6f, 0.4f, 0.4f));;

	modelLoc = glGetUniformLocation(gProgramId, "model");
	viewLoc = glGetUniformLocation(gProgramId, "view");
	projLoc = glGetUniformLocation(gProgramId, "projection");

	// Pass matrix data to the Shader program's matrix uniforms
	glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));
	glUniformMatrix4fv(viewLoc, 1, GL_FALSE, glm::value_ptr(view));
	glUniformMatrix4fv(projLoc, 1, GL_FALSE, glm::value_ptr(projection));

	// Activate the VBO contained within the mesh's VAO
	glBindVertexArray(gMesh.hVAO);

	// bind textures on corresponding texture units
	glActiveTexture(GL_TEXTURE0);
	glBindTexture(GL_TEXTURE_2D, hTextureId);

	glDrawArrays(GL_TRIANGLES, 0, gMesh.nHighlighterVertices);

	glBindVertexArray(0);

	// Cap 1
	model = translate(vec3(1.059f, 0.0f, 0.0f)) * rotate(radians(0.0f), glm::vec3(0.0, 1.0f, 0.0f)) * glm::scale(vec3(0.15f, 0.4f, 0.4f));;

	modelLoc = glGetUniformLocation(gProgramId, "model");
	viewLoc = glGetUniformLocation(gProgramId, "view");
	projLoc = glGetUniformLocation(gProgramId, "projection");

	// Pass matrix data to the Shader program's matrix uniforms
	glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));
	glUniformMatrix4fv(viewLoc, 1, GL_FALSE, glm::value_ptr(view));
	glUniformMatrix4fv(projLoc, 1, GL_FALSE, glm::value_ptr(projection));

	// Activate the VBO contained within the mesh's VAO
	glBindVertexArray(gMesh.hVAO);

	// bind textures on corresponding texture units
	glActiveTexture(GL_TEXTURE0);
	glBindTexture(GL_TEXTURE_2D, h2TextureId);

	glDrawArrays(GL_TRIANGLES, 0, gMesh.nHighlighterVertices);

	glBindVertexArray(0);

	// Cap 2
	model = translate(vec3(2.11f, 0.0f, 0.0f)) * rotate(radians(0.0f), glm::vec3(0.0, 1.0f, 0.0f)) * glm::scale(vec3(0.15f, 0.4f, 0.4f));;

	modelLoc = glGetUniformLocation(gProgramId, "model");
	viewLoc = glGetUniformLocation(gProgramId, "view");
	projLoc = glGetUniformLocation(gProgramId, "projection");

	// Pass matrix data to the Shader program's matrix uniforms
	glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));
	glUniformMatrix4fv(viewLoc, 1, GL_FALSE, glm::value_ptr(view));
	glUniformMatrix4fv(projLoc, 1, GL_FALSE, glm::value_ptr(projection));

	// Activate the VBO contained within the mesh's VAO
	glBindVertexArray(gMesh.hVAO);

	// bind textures on corresponding texture units
	glActiveTexture(GL_TEXTURE0);
	glBindTexture(GL_TEXTURE_2D, h2TextureId);

	glDrawArrays(GL_TRIANGLES, 0, gMesh.nHighlighterVertices);

	glBindVertexArray(0);

	// Clip Peices 

	model = translate(vec3(1.4f, 0.05f, 0.1f)) * rotate(radians(0.0f), glm::vec3(0.2, 0.0f, 0.0f)) * glm::scale(vec3(0.3f, 0.04f, 0.02f));;

	modelLoc = glGetUniformLocation(gProgramId, "model");
	viewLoc = glGetUniformLocation(gProgramId, "view");
	projLoc = glGetUniformLocation(gProgramId, "projection");

	// Pass matrix data to the Shader program's matrix uniforms
	glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));
	glUniformMatrix4fv(viewLoc, 1, GL_FALSE, glm::value_ptr(view));
	glUniformMatrix4fv(projLoc, 1, GL_FALSE, glm::value_ptr(projection));

	// Activate the VBO contained within the mesh's VAO
	glBindVertexArray(gMesh.cVAO);

	// bind textures on corresponding texture units
	glActiveTexture(GL_TEXTURE0);
	glBindTexture(GL_TEXTURE_2D, hTextureId);

	glDrawArrays(GL_TRIANGLES, 0, gMesh.nCubeVertices);

	glBindVertexArray(0);

	model = translate(vec3(1.3f, 0.05f, 0.08f)) * rotate(radians(0.0f), glm::vec3(0.2, 0.0f, 0.0f)) * glm::scale(vec3(0.03f, 0.04f, 0.04f));;

	modelLoc = glGetUniformLocation(gProgramId, "model");
	viewLoc = glGetUniformLocation(gProgramId, "view");
	projLoc = glGetUniformLocation(gProgramId, "projection");

	// Pass matrix data to the Shader program's matrix uniforms
	glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));
	glUniformMatrix4fv(viewLoc, 1, GL_FALSE, glm::value_ptr(view));
	glUniformMatrix4fv(projLoc, 1, GL_FALSE, glm::value_ptr(projection));

	// Activate the VBO contained within the mesh's VAO
	glBindVertexArray(gMesh.cVAO);

	// bind textures on corresponding texture units
	glActiveTexture(GL_TEXTURE0);
	glBindTexture(GL_TEXTURE_2D, hTextureId);

	glDrawArrays(GL_TRIANGLES, 0, gMesh.nCubeVertices);

	glBindVertexArray(0);

	// -------- Paper Weight ------- //
	model = translate(vec3(1.5f, 0.3f,  -0.7f)) * rotate(radians(145.0f), glm::vec3(0.0, 1.0f, 0.0f)) * glm::scale(vec3(0.8f, 0.6f, 0.8f));;

	modelLoc = glGetUniformLocation(gProgramId, "model");
	viewLoc = glGetUniformLocation(gProgramId, "view");
	projLoc = glGetUniformLocation(gProgramId, "projection");

	// Pass matrix data to the Shader program's matrix uniforms
	glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));
	glUniformMatrix4fv(viewLoc, 1, GL_FALSE, glm::value_ptr(view));
	glUniformMatrix4fv(projLoc, 1, GL_FALSE, glm::value_ptr(projection));

	// Activate the VBO contained within the mesh's VAO
	glBindVertexArray(gMesh.pwVAO);

	// bind textures on corresponding texture units
	glActiveTexture(GL_TEXTURE0);
	glBindTexture(GL_TEXTURE_2D, pwTextureId);

	glDrawArrays(GL_TRIANGLES, 0, gMesh.nPaperWeightVertices);

	glBindVertexArray(0);


	// -------- Draw Plane / Desk -------- //
	model = glm::translate(gPlanePosition) * glm::scale(gPlaneScale);

	modelLoc = glGetUniformLocation(gProgramId, "model");
	viewLoc = glGetUniformLocation(gProgramId, "view");
	projLoc = glGetUniformLocation(gProgramId, "projection");

	// Pass matrix data to the Shader program's matrix uniforms
	glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));
	glUniformMatrix4fv(viewLoc, 1, GL_FALSE, glm::value_ptr(view));
	glUniformMatrix4fv(projLoc, 1, GL_FALSE, glm::value_ptr(projection));
	// Activate the VBO contained within the mesh's pVAO
	glBindVertexArray(gMesh.pVAO);

	// bind textures on corresponding texture units
	glActiveTexture(GL_TEXTURE0);
	glBindTexture(GL_TEXTURE_2D, pTextureId);

	glDrawArrays(GL_TRIANGLES, 0, gMesh.nPlaneVertices);

	glBindVertexArray(0);
	

	// ------ Draw Lamp ------- //
	glUseProgram(gLampProgramId);

	glBindVertexArray(gMesh.cVAO);

	model = translate(gLightPosition) * glm::scale(gLightScale);

	// Reference matric uniforms from the lamp shaders
	modelLoc = glGetUniformLocation(gLampProgramId, "model");
	viewLoc = glGetUniformLocation(gLampProgramId, "view");
	projLoc = glGetUniformLocation(gLampProgramId, "projection");

	glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));
	glUniformMatrix4fv(viewLoc, 1, GL_FALSE, glm::value_ptr(view));
	glUniformMatrix4fv(projLoc, 1, GL_FALSE, glm::value_ptr(projection));

	glDrawArrays(GL_TRIANGLES, 0, gMesh.nCubeVertices);
	glBindVertexArray(0);

	// ----- Draw Fill ----- //
	glUseProgram(gFillProgramId);

	model = translate(gFillPosition) * glm::scale(gFillScale);

	modelLoc = glGetUniformLocation(gFillProgramId, "model");
	viewLoc = glGetUniformLocation(gFillProgramId, "view");
	projLoc = glGetUniformLocation(gFillProgramId, "projection");

	glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));
	glUniformMatrix4fv(viewLoc, 1, GL_FALSE, glm::value_ptr(view));
	glUniformMatrix4fv(projLoc, 1, GL_FALSE, glm::value_ptr(projection));

	glDrawArrays(GL_TRIANGLES, 0, gMesh.nCubeVertices);

	// Deactivate the Vertex Array Object
	glBindVertexArray(0);
	glUseProgram(0);

	// glfw: swap buffers and poll IO events 
	glfwSwapBuffers(gWindow);
}


/* Creates mesh for objects  /
/  ----------------------- */
void createMesh(GLMesh& mesh) {

	// Position and Color data
	GLfloat plane[] = {
		// Positions             // Normals			  // Texture  //
		// -------------------------------------------------------//
		-1.0f, 0.0f, -0.7f,		0.0f,  1.0f,  0.0f,		0.0f, 0.0f,
		 2.3f, 0.0f, -0.7f,		0.0f,  1.0f,  0.0f,		1.0f, 0.0f,
		 2.3f, 0.0f,  1.0f,		0.0f,  1.0f,  0.0f,		1.0f, 1.0f,
		-1.0f, 0.0f, -0.7f,		0.0f,  1.0f,  0.0f,		0.0f, 0.0f,
		 2.3f, 0.0f,  1.0f,		0.0f,  1.0f,  0.0f,		1.0f, 1.0f,
		-1.0f, 0.0f,  1.0f,		0.0f,  1.0f,  0.0f,		0.0f, 1.0f
	};

	GLfloat bookPages[] = {
		// Positions             // Normals			  // Texture  //
		// -------------------------------------------------------//
		// Back Face
		-0.25f, 0.0f, -0.58f,		0.0f,  0.0f, -1.0f,		0.0f, 0.0f,
		 0.51f, 0.0f, -0.37f,		0.0f,  0.0f, -1.0f,		1.0f, 0.0f,
		 0.51f, 0.2f, -0.37f,		0.0f,  0.0f, -1.0f,		1.0f, 0.0f,
		-0.25f, 0.0f, -0.58f,		0.0f,  0.0f, -1.0f,		0.0f, 0.0f,
		 0.51f, 0.2f, -0.37f,		0.0f,  0.0f, -1.0f,		1.0f, 0.0f,
		-0.25f, 0.2f, -0.58f,		0.0f,  0.0f, -1.0f,		0.0f, 0.0f,
		// Right Face
		 0.51f, 0.0f, -0.37f,		1.0f,  0.0f,  0.0f,		1.0f, 0.0f,
		 0.51f, 0.2f, -0.37f,		1.0f,  0.0f,  0.0f,		1.0f, 0.0f,
		 0.25f, 0.0f,  0.58f,		1.0f,  0.0f,  0.0f,		1.0f, 1.0f,
		 0.51f, 0.2f, -0.37f,		1.0f,  0.0f,  0.0f,		1.0f, 0.0f,
		 0.25f, 0.0f,  0.58f,		1.0f,  0.0f,  0.0f,		1.0f, 1.0f,
		 0.25f, 0.2f,  0.58f,		1.0f,  0.0f,  0.0f,		1.0f, 1.0f,
		 // Left Face
		 -0.25f, 0.0f, -0.58f,		-1.0f,  0.0f,  0.0f,	0.0f, 0.0f,
		 -0.51f, 0.0f,  0.37f,		-1.0f,  0.0f,  0.0f,	0.0f, 1.0f,
		 -0.51f, 0.2f,  0.37f,		-1.0f,  0.0f,  0.0f,	0.0f, 1.0f,
		 -0.25f, 0.0f, -0.58f,		-1.0f,  0.0f,  0.0f,	0.0f, 0.0f,
		 -0.25f, 0.2f, -0.58f,		-1.0f,  0.0f,  0.0f,	0.0f, 0.0f,
		 -0.51f, 0.2f,  0.37f,		-1.0f,  0.0f,  0.0f,	0.0f, 1.0f,
		 // Bottom Face
		 -0.25f, 0.0f, -0.58f,		0.0f, -1.0f,  0.0f,		0.0f, 0.0f,
		  0.51f, 0.0f, -0.37f,		0.0f, -1.0f,  0.0f,		1.0f, 0.0f,
		  0.25f, 0.0f,  0.58f,		0.0f, -1.0f,  0.0f,		1.0f, 1.0f,
		 -0.25f, 0.0f, -0.58f,		0.0f, -1.0f,  0.0f,		0.0f, 0.0f,
		  0.25f, 0.0f,  0.58f,		0.0f, -1.0f,  0.0f,		1.0f, 1.0f,
		 -0.51f, 0.0f,  0.37f,		0.0f, -1.0f,  0.0f,		0.0f, 1.0f,
		 // Top Face
		  0.51f, 0.2f, -0.37f,		0.0f,  1.0f,  0.0f,		1.0f, 0.0f,
		 -0.25f, 0.2f, -0.58f,		0.0f,  1.0f,  0.0f,		0.0f, 0.0f,
		 -0.51f, 0.2f,  0.37f,		0.0f,  1.0f,  0.0f,		0.0f, 1.0f,
		  0.51f, 0.2f, -0.37f,		0.0f,  1.0f,  0.0f,		1.0f, 0.0f,
		  0.25f, 0.2f,  0.58f,		0.0f,  1.0f,  0.0f,		1.0f, 1.0f,
		 -0.51f, 0.2f,  0.37f,		0.0f,  1.0f,  0.0f,		0.0f, 1.0f,
		 // Front Face
		 0.25f, 0.0f,  0.58f,		0.0f,  0.0f,  1.0f,		1.0f, 1.0f,
		 0.25f, 0.2f,  0.58f,		0.0f,  0.0f,  1.0f,		1.0f, 1.0f,
		-0.51f, 0.0f,  0.37f,		0.0f,  0.0f,  1.0f,		0.0f, 1.0f,
		 0.25f, 0.2f,  0.58f,		0.0f,  0.0f,  1.0f,		1.0f, 1.0f,
		-0.51f, 0.0f,  0.37f,		0.0f,  0.0f,  1.0f,		0.0f, 1.0f,
		-0.51f, 0.2f,  0.37f,		0.0f,  0.0f,  1.0f,		0.0f, 1.0f

	};

	GLfloat bookCover[] = {
		// Positions					// Normals				// Texture   //
		// ----------------------------------------------------------------- //
		// Left Face
		-0.27f, -0.01f, -0.60f,		-1.0f,  0.0f, 0.0f,			0.0f, 0.0f,
		-0.27f,  0.21f, -0.60f,		-1.0f,  0.0f, 0.0f,			0.0f, 0.0f,
		-0.53f,  0.21f,  0.39f,		-1.0f,  0.0f, 0.0f,			1.0f, 0.0f,
		-0.27f, -0.01f, -0.60f,		-1.0f,  0.0f, 0.0f,			0.0f, 0.0f,
		-0.53f,  0.21f,  0.39f,		-1.0f,  0.0f, 0.0f,			1.0f, 0.0f,
		-0.53f, -0.01f,  0.39f,		-1.0f,  0.0f, 0.0f,			1.0f, 0.0f,
		// Top Face
	   -0.27f,  0.21f, -0.60f,		0.0f,  1.0f,  0.0f,			0.0f, 0.0f,
		0.53f,  0.21f, -0.39f,		0.0f,  1.0f,  0.0f,			1.0f, 0.0f,
		0.27f,  0.21f,  0.60f,		0.0f,  1.0f,  0.0f,			1.0f, 1.0f,
	   -0.27f,  0.21f, -0.60f,		0.0f,  1.0f,  0.0f,			0.0f, 0.0f,
		0.27f,  0.21f,  0.60f,		0.0f,  1.0f,  0.0f,			1.0f, 1.0f,
	   -0.53f,  0.21f,  0.39f,		0.0f,  1.0f,  0.0f,			0.0f, 1.0f,
	   // Bottom Face
	   -0.27f,  0.001f, -0.60f,		0.0f, -1.0f,  0.0f,			0.0f, 0.0f,
	   -0.53f,  0.001f,  0.39f,		0.0f, -1.0f,  0.0f,			0.0f, 1.0f,
		0.53f,  0.001f, -0.39f,		0.0f, -1.0f,  0.0f,			1.0f, 0.0f,
	   -0.53f,  0.001f,  0.39f,		0.0f, -1.0f,  0.0f,			0.0f, 1.0f,
		0.27f,  0.001f,  0.60f,		0.0f, -1.0f,  0.0f,			1.0f, 1.0f,
		0.53f,  0.001f, -0.39f,		0.0f, -1.0f,  0.0f,			1.0f, 0.0f,
	};

	GLfloat stickyPadsPlane[] = {
		// Positions				// Normals			// Texture   //
		// --------------------------------------------------------- //
		// Base plane			
		0.9f, 0.001f, 0.0f,		0.0f,  1.0f,  0.0f,		1.0f, 0.0f,
		0.9f, 0.001f, 0.8f,		0.0f,  1.0f,  0.0f,		1.0f, 0.0f,
		1.2f, 0.001f, 0.0f,		0.0f,  1.0f,  0.0f,		1.0f, 0.0f,
		0.9f, 0.001f, 0.8f,		0.0f,  1.0f,  0.0f,		1.0f, 0.0f,
		1.2f, 0.001f, 0.0f,		0.0f,  1.0f,  0.0f,		1.0f, 0.0f,
		1.2f, 0.001f, 0.8f,		0.0f,  1.0f,  0.0f,		1.0f, 0.0f,
	};

	GLfloat stickyPads[] = {
		// Positions				// Normals				// Texture   //
		// ------------------------------------------------------------- //
		/* Sticky Pad One */
		// left
		0.95f, 0.001f, 0.15f,	-1.0f,  0.0f,  0.0f,		1.0f, 1.0f,
		0.95f, 0.001f, 0.20f,	-1.0f,  0.0f,  0.0f,		1.0f, 1.0f,
		0.95f, 0.01f,  0.15f,	-1.0f,  0.0f,  0.0f,		1.0f, 1.0f,
		0.95f, 0.001f, 0.20f,	-1.0f,  0.0f,  0.0f,		1.0f, 1.0f,
		0.95f, 0.01f,  0.15f,	-1.0f,  0.0f,  0.0f,		1.0f, 1.0f,
		0.95f, 0.01f,  0.20f,	-1.0f,  0.0f,  0.0f,		1.0f, 1.0f,
		// right
		1.15f, 0.001f, 0.15f,	1.0f,  0.0f,  0.0f,			1.0f, 1.0f,
		1.15f, 0.001f, 0.20f,	1.0f,  0.0f,  0.0f,			1.0f, 1.0f,
		1.15f, 0.01f,  0.15f,	1.0f,  0.0f,  0.0f,			1.0f, 1.0f,
		1.15f, 0.001f, 0.20f,	1.0f,  0.0f,  0.0f,			1.0f, 1.0f,
		1.15f, 0.01f,  0.15f,	1.0f,  0.0f,  0.0f,			1.0f, 1.0f,
		1.15f, 0.01f,  0.20f,	1.0f,  0.0f,  0.0f,			1.0f, 1.0f,
		// back
		0.95f, 0.001f, 0.15f,	0.0f,  0.0f,  -1.0f,		1.0f, 1.0f,
		1.15f, 0.001f, 0.15f,	0.0f,  0.0f,  -1.0f,		1.0f, 1.0f,
		0.95f, 0.01f,  0.15f,	0.0f,  0.0f,  -1.0f,		1.0f, 1.0f,
		0.95f, 0.01f,  0.15f,	0.0f,  0.0f,  -1.0f,		1.0f, 1.0f,
		1.15f, 0.001f, 0.15f,	0.0f,  0.0f,  -1.0f,		1.0f, 1.0f,
		1.15f, 0.01f,  0.15f,	0.0f,  0.0f,  -1.0f,		1.0f, 1.0f,
		// front
		0.95f, 0.001f, 0.20f,	0.0f,  0.0f,   1.0f,		1.0f, 1.0f,
		1.15f, 0.001f, 0.20f,	0.0f,  0.0f,   1.0f,		1.0f, 1.0f,
		0.95f, 0.01f,  0.20f,	0.0f,  0.0f,   1.0f,		1.0f, 1.0f,
		0.95f, 0.01f,  0.20f,	0.0f,  0.0f,   1.0f,		1.0f, 1.0f,
		1.15f, 0.001f, 0.20f,	0.0f,  0.0f,   1.0f,		1.0f, 1.0f,
		1.15f, 0.01f,  0.20f,	0.0f,  0.0f,   1.0f,		1.0f, 1.0f,
		// top
		0.95f, 0.01f,  0.15f,	0.0f,  1.0f,   0.0f,		1.0f, 1.0f,
		1.15f, 0.01f,  0.15f,	0.0f,  1.0f,   0.0f,		1.0f, 1.0f,
		1.15f, 0.01f,  0.20f,	0.0f,  1.0f,   0.0f,		1.0f, 1.0f,
		0.95f, 0.01f,  0.15f,	0.0f,  1.0f,   0.0f,		1.0f, 1.0f,
		0.95f, 0.01f,  0.20f,	0.0f,  1.0f,   0.0f,		1.0f, 1.0f,
		1.15f, 0.01f,  0.20f,	0.0f,  1.0f,   0.0f,		1.0f, 1.0f,
		/* Sticky Pad Two */
		// left
		0.95f, 0.001f, 0.25f,	-1.0f,  0.0f,  0.0f,		1.0f, 1.0f,
		0.95f, 0.001f, 0.30f,	-1.0f,  0.0f,  0.0f,		1.0f, 1.0f,
		0.95f, 0.01f,  0.25f,	-1.0f,  0.0f,  0.0f,		1.0f, 1.0f,
		0.95f, 0.001f, 0.30f,	-1.0f,  0.0f,  0.0f,		1.0f, 1.0f,
		0.95f, 0.01f,  0.25f,	-1.0f,  0.0f,  0.0f,		1.0f, 1.0f,
		0.95f, 0.01f,  0.30f,	-1.0f,  0.0f,  0.0f,		1.0f, 1.0f,
		// right
		1.15f, 0.001f, 0.25f,	1.0f,  0.0f,  0.0f,			1.0f, 1.0f,
		1.15f, 0.001f, 0.30f,	1.0f,  0.0f,  0.0f,			1.0f, 1.0f,
		1.15f, 0.01f,  0.25f,	1.0f,  0.0f,  0.0f,			1.0f, 1.0f,
		1.15f, 0.001f, 0.30f,	1.0f,  0.0f,  0.0f,			1.0f, 1.0f,
		1.15f, 0.01f,  0.25f,	1.0f,  0.0f,  0.0f,			1.0f, 1.0f,
		1.15f, 0.01f,  0.30f,	1.0f,  0.0f,  0.0f,			1.0f, 1.0f,
		// back
		0.95f, 0.001f, 0.25f,	0.0f,  0.0f,  -1.0f,		1.0f, 1.0f,
		1.15f, 0.001f, 0.25f,	0.0f,  0.0f,  -1.0f,		1.0f, 1.0f,
		0.95f, 0.01f,  0.25f,	0.0f,  0.0f,  -1.0f,		1.0f, 1.0f,
		0.95f, 0.01f,  0.25f,	0.0f,  0.0f,  -1.0f,		1.0f, 1.0f,
		1.15f, 0.001f, 0.25f,	0.0f,  0.0f,  -1.0f,		1.0f, 1.0f,
		1.15f, 0.01f,  0.25f,	0.0f,  0.0f,  -1.0f,		1.0f, 1.0f,
		// front
		0.95f, 0.001f, 0.30f,	0.0f,  0.0f,   1.0f,		1.0f, 1.0f,
		1.15f, 0.001f, 0.30f,	0.0f,  0.0f,   1.0f,		1.0f, 1.0f,
		0.95f, 0.01f,  0.30f,	0.0f,  0.0f,   1.0f,		1.0f, 1.0f,
		0.95f, 0.01f,  0.30f,	0.0f,  0.0f,   1.0f,		1.0f, 1.0f,
		1.15f, 0.001f, 0.30f,	0.0f,  0.0f,   1.0f,		1.0f, 1.0f,
		1.15f, 0.01f,  0.30f,	0.0f,  0.0f,   1.0f,		1.0f, 1.0f,
		// top
		0.95f, 0.01f,  0.25f,	0.0f,  1.0f,   0.0f,		1.0f, 1.0f,
		1.15f, 0.01f,  0.25f,	0.0f,  1.0f,   0.0f,		1.0f, 1.0f,
		1.15f, 0.01f,  0.30f,	0.0f,  1.0f,   0.0f,		1.0f, 1.0f,
		0.95f, 0.01f,  0.25f,	0.0f,  1.0f,   0.0f,		1.0f, 1.0f,
		0.95f, 0.01f,  0.30f,	0.0f,  1.0f,   0.0f,		1.0f, 1.0f,
		1.15f, 0.01f,  0.30f,	0.0f,  1.0f,   0.0f,		1.0f, 1.0f,
		/* Sticky Pad Three */
		// left
		0.95f, 0.001f, 0.35f,	-1.0f,  0.0f,  0.0f,		1.0f, 1.0f,
		0.95f, 0.001f, 0.40f,	-1.0f,  0.0f,  0.0f,		1.0f, 1.0f,
		0.95f, 0.01f,  0.35f,	-1.0f,  0.0f,  0.0f,		1.0f, 1.0f,
		0.95f, 0.001f, 0.40f,	-1.0f,  0.0f,  0.0f,		1.0f, 1.0f,
		0.95f, 0.01f,  0.35f,	-1.0f,  0.0f,  0.0f,		1.0f, 1.0f,
		0.95f, 0.01f,  0.40f,	-1.0f,  0.0f,  0.0f,		1.0f, 1.0f,
		// right
		1.15f, 0.001f, 0.35f,	1.0f,  0.0f,  0.0f,			1.0f, 1.0f,
		1.15f, 0.001f, 0.40f,	1.0f,  0.0f,  0.0f,			1.0f, 1.0f,
		1.15f, 0.01f,  0.35f,	1.0f,  0.0f,  0.0f,			1.0f, 1.0f,
		1.15f, 0.001f, 0.40f,	1.0f,  0.0f,  0.0f,			1.0f, 1.0f,
		1.15f, 0.01f,  0.35f,	1.0f,  0.0f,  0.0f,			1.0f, 1.0f,
		1.15f, 0.01f,  0.40f,	1.0f,  0.0f,  0.0f,			1.0f, 1.0f,
		// back
		0.95f, 0.001f, 0.35f,	0.0f,  0.0f,  -1.0f,		1.0f, 1.0f,
		1.15f, 0.001f, 0.35f,	0.0f,  0.0f,  -1.0f,		1.0f, 1.0f,
		0.95f, 0.01f,  0.35f,	0.0f,  0.0f,  -1.0f,		1.0f, 1.0f,
		0.95f, 0.01f,  0.35f,	0.0f,  0.0f,  -1.0f,		1.0f, 1.0f,
		1.15f, 0.001f, 0.35f,	0.0f,  0.0f,  -1.0f,		1.0f, 1.0f,
		1.15f, 0.01f,  0.35f,	0.0f,  0.0f,  -1.0f,		1.0f, 1.0f,
		// front
		0.95f, 0.001f, 0.40f,	0.0f,  0.0f,   1.0f,		1.0f, 1.0f,
		1.15f, 0.001f, 0.40f,	0.0f,  0.0f,   1.0f,		1.0f, 1.0f,
		0.95f, 0.01f,  0.40f,	0.0f,  0.0f,   1.0f,		1.0f, 1.0f,
		0.95f, 0.01f,  0.40f,	0.0f,  0.0f,   1.0f,		1.0f, 1.0f,
		1.15f, 0.001f, 0.40f,	0.0f,  0.0f,   1.0f,		1.0f, 1.0f,
		1.15f, 0.01f,  0.40f,	0.0f,  0.0f,   1.0f,		1.0f, 1.0f,
		// top
		0.95f, 0.01f,  0.35f,	0.0f,  1.0f,   0.0f,		1.0f, 1.0f,
		1.15f, 0.01f,  0.35f,	0.0f,  1.0f,   0.0f,		1.0f, 1.0f,
		1.15f, 0.01f,  0.40f,	0.0f,  1.0f,   0.0f,		1.0f, 1.0f,
		0.95f, 0.01f,  0.35f,	0.0f,  1.0f,   0.0f,		1.0f, 1.0f,
		0.95f, 0.01f,  0.40f,	0.0f,  1.0f,   0.0f,		1.0f, 1.0f,
		1.15f, 0.01f,  0.40f,	0.0f,  1.0f,   0.0f,		1.0f, 1.0f,
		/* Sticky Pad Four */
		// left
		0.95f, 0.001f, 0.45f,	-1.0f,  0.0f,  0.0f,		1.0f, 1.0f,
		0.95f, 0.001f, 0.50f,	-1.0f,  0.0f,  0.0f,		1.0f, 1.0f,
		0.95f, 0.01f,  0.45f,	-1.0f,  0.0f,  0.0f,		1.0f, 1.0f,
		0.95f, 0.001f, 0.50f,	-1.0f,  0.0f,  0.0f,		1.0f, 1.0f,
		0.95f, 0.01f,  0.45f,	-1.0f,  0.0f,  0.0f,		1.0f, 1.0f,
		0.95f, 0.01f,  0.50f,	-1.0f,  0.0f,  0.0f,		1.0f, 1.0f,
		// right
		1.15f, 0.001f, 0.45f,	1.0f,  0.0f,  0.0f,			1.0f, 1.0f,
		1.15f, 0.001f, 0.50f,	1.0f,  0.0f,  0.0f,			1.0f, 1.0f,
		1.15f, 0.01f,  0.45f,	1.0f,  0.0f,  0.0f,			1.0f, 1.0f,
		1.15f, 0.001f, 0.50f,	1.0f,  0.0f,  0.0f,			1.0f, 1.0f,
		1.15f, 0.01f,  0.45f,	1.0f,  0.0f,  0.0f,			1.0f, 1.0f,
		1.15f, 0.01f,  0.50f,	1.0f,  0.0f,  0.0f,			1.0f, 1.0f,
		// back
		0.95f, 0.001f, 0.45f,	0.0f,  0.0f,  -1.0f,		1.0f, 1.0f,
		1.15f, 0.001f, 0.45f,	0.0f,  0.0f,  -1.0f,		1.0f, 1.0f,
		0.95f, 0.01f,  0.45f,	0.0f,  0.0f,  -1.0f,		1.0f, 1.0f,
		0.95f, 0.01f,  0.45f,	0.0f,  0.0f,  -1.0f,		1.0f, 1.0f,
		1.15f, 0.001f, 0.45f,	0.0f,  0.0f,  -1.0f,		1.0f, 1.0f,
		1.15f, 0.01f,  0.45f,	0.0f,  0.0f,  -1.0f,		1.0f, 1.0f,
		// front
		0.95f, 0.001f, 0.50f,	0.0f,  0.0f,   1.0f,		1.0f, 1.0f,
		1.15f, 0.001f, 0.50f,	0.0f,  0.0f,   1.0f,		1.0f, 1.0f,
		0.95f, 0.01f,  0.50f,	0.0f,  0.0f,   1.0f,		1.0f, 1.0f,
		0.95f, 0.01f,  0.50f,	0.0f,  0.0f,   1.0f,		1.0f, 1.0f,
		1.15f, 0.001f, 0.50f,	0.0f,  0.0f,   1.0f,		1.0f, 1.0f,
		1.15f, 0.01f,  0.50f,	0.0f,  0.0f,   1.0f,		1.0f, 1.0f,
		// top
		0.95f, 0.01f,  0.45f,	0.0f,  1.0f,   0.0f,		1.0f, 1.0f,
		1.15f, 0.01f,  0.45f,	0.0f,  1.0f,   0.0f,		1.0f, 1.0f,
		1.15f, 0.01f,  0.50f,	0.0f,  1.0f,   0.0f,		1.0f, 1.0f,
		0.95f, 0.01f,  0.45f,	0.0f,  1.0f,   0.0f,		1.0f, 1.0f,
		0.95f, 0.01f,  0.50f,	0.0f,  1.0f,   0.0f,		1.0f, 1.0f,
		1.15f, 0.01f,  0.50f,	0.0f,  1.0f,   0.0f,		1.0f, 1.0f,

	};

	GLfloat cylinder[] = {
		// Positions				// Normals					// Texture   //
		// ----------------------------------------------------------------- //
		// Left side
		0.6f, 0.1f, 0.0f,				-1.0f,  0.0f,  0.0f,		1.0f, 0.0f,
		0.6f, 0.1f, 0.10f,				-1.0f,  0.0f,  0.0f,		1.0f, 0.0f,
		0.6f, 0.0f, 0.05f,				-1.0f,  0.0f,  0.0f,		1.0f, 0.0f,
		0.6f, 0.0f, 0.05f,				-1.0f,  0.0f,  0.0f,		1.0f, 0.0f,
		0.6f, 0.1f, 0.10f,				-1.0f,  0.0f,  0.0f,		1.0f, 0.0f,
		0.6f, 0.0f, 0.15f,				-1.0f,  0.0f,  0.0f,		1.0f, 0.0f,
		0.6f, 0.0f, 0.15f,				-1.0f,  0.0f,  0.0f,		1.0f, 0.0f,
		0.6f, 0.1f, 0.10f,				-1.0f,  0.0f,  0.0f,		1.0f, 0.0f,
		0.6f, 0.1f, 0.20f,				-1.0f,  0.0f,  0.0f,		1.0f, 0.0f,					
		0.6f, 0.1f, 0.20f,				-1.0f,  0.0f,  0.0f,		1.0f, 0.0f,
		0.6f, 0.1f, 0.10f,				-1.0f,  0.0f,  0.0f,		1.0f, 0.0f,
		0.6f, 0.2f, 0.15f,				-1.0f,  0.0f,  0.0f,		1.0f, 0.0f,
		0.6f, 0.2f, 0.15f,				-1.0f,  0.0f,  0.0f,		1.0f, 0.0f,
		0.6f, 0.1f, 0.10f,				-1.0f,  0.0f,  0.0f,		1.0f, 0.0f,
		0.6f, 0.2f, 0.05f,				-1.0f,  0.0f,  0.0f,		1.0f, 0.0f,	
		0.6f, 0.2f, 0.05f,				-1.0f,  0.0f,  0.0f,		1.0f, 0.0f,
		0.6f, 0.1f, 0.10f,				-1.0f,  0.0f,  0.0f,		1.0f, 0.0f,
		0.6f, 0.1f, 0.0f,				-1.0f,  0.0f,  0.0f,		1.0f, 0.0f,
		// right side
		2.0f, 0.1f, 0.0f,				 1.0f,  0.0f,  0.0f,		1.0f, 0.0f,
		2.0f, 0.1f, 0.10f,				 1.0f,  0.0f,  0.0f,		1.0f, 0.0f,
		2.0f, 0.0f, 0.05f,				 1.0f,  0.0f,  0.0f,		1.0f, 0.0f,
		2.0f, 0.0f, 0.05f,				 1.0f,  0.0f,  0.0f,		1.0f, 0.0f,
		2.0f, 0.1f, 0.10f,				 1.0f,  0.0f,  0.0f,		1.0f, 0.0f,
		2.0f, 0.0f, 0.15f,				 1.0f,  0.0f,  0.0f,		1.0f, 0.0f,
		2.0f, 0.0f, 0.15f,				 1.0f,  0.0f,  0.0f,		1.0f, 0.0f,
		2.0f, 0.1f, 0.10f,				 1.0f,  0.0f,  0.0f,		1.0f, 0.0f,
		2.0f, 0.1f, 0.20f,				 1.0f,  0.0f,  0.0f,		1.0f, 0.0f,
		2.0f, 0.1f, 0.20f,				 1.0f,  0.0f,  0.0f,		1.0f, 0.0f,
		2.0f, 0.1f, 0.10f,				 1.0f,  0.0f,  0.0f,		1.0f, 0.0f,
		2.0f, 0.2f, 0.15f,				 1.0f,  0.0f,  0.0f,		1.0f, 0.0f,
		2.0f, 0.2f, 0.15f,				 1.0f,  0.0f,  0.0f,		1.0f, 0.0f,
		2.0f, 0.1f, 0.10f,				 1.0f,  0.0f,  0.0f,		1.0f, 0.0f,
		2.0f, 0.2f, 0.05f,				 1.0f,  0.0f,  0.0f,		1.0f, 0.0f,
		2.0f, 0.2f, 0.05f,				 1.0f,  0.0f,  0.0f,		1.0f, 0.0f,
		2.0f, 0.1f, 0.10f,				 1.0f,  0.0f,  0.0f,		1.0f, 0.0f,
		2.0f, 0.1f, 0.0f,				 1.0f,  0.0f,  0.0f,		1.0f, 0.0f,

		/* ----- Sides -----*/
		0.6f, 0.1f, 0.0f,				0.0f,  0.0f,  -1.0f,			1.0f, 0.0f,
		0.6f, 0.0f, 0.05f,				0.0f,  0.0f,  -1.0f,			1.0f, 0.0f,
		2.0f, 0.1f, 0.0f,				0.0f,  0.0f,  -1.0f,			1.0f, 0.0f,
		0.6f, 0.0f, 0.05f,				0.0f,  0.0f,  -1.0f,			1.0f, 0.0f,
		2.0f, 0.1f, 0.0f,				0.0f,  0.0f,  -1.0f,			1.0f, 0.0f,
		2.0f, 0.0f, 0.05f,				0.0f,  0.0f,  -1.0f,			1.0f, 0.0f,

		0.6f, 0.0f, 0.05f,				 0.0f,  -1.0f,  0.0f,		1.0f, 0.0f,
		0.6f, 0.0f, 0.15f,				 0.0f,  -1.0f,  0.0f,		1.0f, 0.0f,
		2.0f, 0.0f, 0.05f,				 0.0f,  -1.0f,  0.0f,		1.0f, 0.0f,
		2.0f, 0.0f, 0.05f,				 0.0f,  -1.0f,  0.0f,		1.0f, 0.0f,
		2.0f, 0.0f, 0.15f,				 1.0f,  -1.0f,  0.0f,		1.0f, 0.0f,
		0.6f, 0.0f, 0.15f,				 0.0f,  -1.0f,  0.0f,		1.0f, 0.0f,

		0.6f, 0.0f, 0.15f,				0.0f,  0.0f,  1.0f,		1.0f, 0.0f,
		0.6f, 0.1f, 0.20f,				0.0f,  0.0f,  1.0f,		1.0f, 0.0f,
		2.0f, 0.0f, 0.15f,				0.0f,  0.0f,  1.0f,		1.0f, 0.0f,
		2.0f, 0.0f, 0.15f,				0.0f,  0.0f,  1.0f,		1.0f, 0.0f,
		2.0f, 0.1f, 0.20f,				0.0f,  0.0f,  1.0f,		1.0f, 0.0f,
		0.6f, 0.1f, 0.20f,				0.0f,  0.0f,  1.0f,		1.0f, 0.0f,

		0.6f, 0.1f, 0.20f,				 0.0f,  0.0f,  1.0f,		1.0f, 0.0f,
		0.6f, 0.2f, 0.15f,				 0.0f,  0.0f,  1.0f,		1.0f, 0.0f,
		2.0f, 0.1f, 0.20f,				 0.0f,  0.0f,  1.0f,		1.0f, 0.0f,
		2.0f, 0.1f, 0.20f,				 0.0f,  0.0f,  1.0f,		1.0f, 0.0f,
		2.0f, 0.2f, 0.15f,				 0.0f,  0.0f,  1.0f,		1.0f, 0.0f,
		0.6f, 0.2f, 0.15f,				 0.0f,  0.0f,  1.0f,		1.0f, 0.0f,

		0.6f, 0.2f, 0.15f,				 0.0f,  1.0f,  0.0f,		1.0f, 0.0f,
		0.6f, 0.2f, 0.05f,				 0.0f,  1.0f,  0.0f,		1.0f, 0.0f,
		2.0f, 0.2f, 0.15f,				 0.0f,  1.0f,  0.0f,		1.0f, 0.0f,
		2.0f, 0.2f, 0.15f,				 0.0f,  1.0f,  0.0f,		1.0f, 0.0f,
		2.0f, 0.2f, 0.05f,				 0.0f,  1.0f,  0.0f,		1.0f, 0.0f,
		0.6f, 0.2f, 0.05f,				 0.0f,  1.0f,  0.0f,		1.0f, 0.0f,

		0.6f, 0.2f, 0.05f,				 0.0f,   0.0f,  -1.0f,		1.0f, 0.0f,
		0.6f, 0.1f, 0.0f,				 0.0f,   0.0f,  -1.0f,		1.0f, 0.0f,
		2.0f, 0.2f, 0.05f,				 0.0f,   0.0f,  -1.0f,		1.0f, 0.0f,
		2.0f, 0.2f, 0.05f,				 0.0f,   0.0f,  -1.0f,		1.0f, 0.0f,
		2.0f, 0.1f, 0.0f,				 0.0f,   0.0f,  -1.0f,		1.0f, 0.0f,
		0.6f, 0.1f, 0.0f,				 0.0f,   0.0f,  -1.0f,		1.0f, 0.0f,

	};	

	GLfloat paperWeight[] = {
		// Positions				// Normals			// Texture   //
		// --------------------------------------------------------- //
		// bottom
		-0.5f, -0.5f,  0.5f,	0.0f, -1.0f,  0.0f,		0.0f, 1.0f,
		-0.5f, -0.5f, -0.5f,    0.0f, -1.0f,  0.0f,		0.0f, 0.0f,
		 0.5f, -0.5f, -0.5f,    0.0f, -1.0f,  0.0f,		1.0f, 0.0f,
		 0.5f, -0.5f,  0.5f,    0.0f, -1.0f,  0.0f,		1.0f, 1.0f,
		 0.5f, -0.5f, -0.5f,    0.0f, -1.0f,  0.0f,		1.0f, 0.0f,
		-0.5f, -0.5f,  0.5f,    0.0f, -1.0f,  0.0f,		0.0f, 1.0f,
		// front
		-0.5f, -0.5f,  0.5f,    0.0f,  0.0f,  1.0f,		0.0f, 0.0f,
		 0.5f, -0.5f,  0.5f,    0.0f,  0.0f,  1.0f,		1.0f, 0.0f,
		 0.0f,  0.5f,  0.0f,    0.0f,  0.0f,  1.0f,		1.0f, 1.0f,
		 // left
		-0.5f, -0.5f, -0.5f,	-1.0f,  0.0f, 0.0f,		0.0f, 0.0f,
		-0.5f, -0.5f,  0.5f,	-1.0f,  0.0f, 0.0f,		1.0f, 0.0f,
		 0.0f,  0.5f,  0.0f,	-1.0f,  0.0f, 0.0f,		0.0f, 1.0f,
		 // back
		-0.5f, -0.5f, -0.5f,	0.0f,  0.0f, -1.0f,		0.0f, 0.0f,
		 0.5f, -0.5f, -0.5f,	0.0f,  0.0f, -1.0f,		1.0f, 0.0f,
		 0.0f,  0.5f,  0.0f,	0.0f,  0.0f, -1.0f,		0.0f, 1.0f,
		 // right
		0.5f, -0.5f, -0.5f,		1.0f,  0.0f, 0.0f,		1.0f, 0.0f,
		0.5f, -0.5f,  0.5f,		1.0f,  0.0f, 0.0f,		0.0f, 0.0f,
		0.0f,  0.5f,  0.0f,		1.0f,  0.0f, 0.0f,		0.0f, 1.0f
	};

	GLfloat cubeVerts[] = {
		// Positions			// Normals			// Texture   //
// ------------------------------------------------------------- //
		//Back Face         
		-0.5f, -0.5f, -0.5f,  0.0f,  0.0f, -1.0f,  0.0f, 0.0f,
		 0.5f, -0.5f, -0.5f,  0.0f,  0.0f, -1.0f,  1.0f, 0.0f,
		 0.5f,  0.5f, -0.5f,  0.0f,  0.0f, -1.0f,  1.0f, 1.0f,
		 0.5f,  0.5f, -0.5f,  0.0f,  0.0f, -1.0f,  1.0f, 1.0f,
		-0.5f,  0.5f, -0.5f,  0.0f,  0.0f, -1.0f,  0.0f, 1.0f,
		-0.5f, -0.5f, -0.5f,  0.0f,  0.0f, -1.0f,  0.0f, 0.0f,

		//Front Face        
		-0.5f, -0.5f,  0.5f,  0.0f,  0.0f,  1.0f,  0.0f, 0.0f,
		 0.5f, -0.5f,  0.5f,  0.0f,  0.0f,  1.0f,  1.0f, 0.0f,
		 0.5f,  0.5f,  0.5f,  0.0f,  0.0f,  1.0f,  1.0f, 1.0f,
		 0.5f,  0.5f,  0.5f,  0.0f,  0.0f,  1.0f,  1.0f, 1.0f,
		-0.5f,  0.5f,  0.5f,  0.0f,  0.0f,  1.0f,  0.0f, 1.0f,
		-0.5f, -0.5f,  0.5f,  0.0f,  0.0f,  1.0f,  0.0f, 0.0f,

		//Left Face          
		-0.5f,  0.5f,  0.5f, -1.0f,  0.0f,  0.0f,  1.0f, 0.0f,
		-0.5f,  0.5f, -0.5f, -1.0f,  0.0f,  0.0f,  1.0f, 1.0f,
		-0.5f, -0.5f, -0.5f, -1.0f,  0.0f,  0.0f,  0.0f, 1.0f,
		-0.5f, -0.5f, -0.5f, -1.0f,  0.0f,  0.0f,  0.0f, 1.0f,
		-0.5f, -0.5f,  0.5f, -1.0f,  0.0f,  0.0f,  0.0f, 0.0f,
		-0.5f,  0.5f,  0.5f, -1.0f,  0.0f,  0.0f,  1.0f, 0.0f,

		//Right Face         
		 0.5f,  0.5f,  0.5f,  1.0f,  0.0f,  0.0f,  1.0f, 0.0f,
		 0.5f,  0.5f, -0.5f,  1.0f,  0.0f,  0.0f,  1.0f, 1.0f,
		 0.5f, -0.5f, -0.5f,  1.0f,  0.0f,  0.0f,  0.0f, 1.0f,
		 0.5f, -0.5f, -0.5f,  1.0f,  0.0f,  0.0f,  0.0f, 1.0f,
		 0.5f, -0.5f,  0.5f,  1.0f,  0.0f,  0.0f,  0.0f, 0.0f,
		 0.5f,  0.5f,  0.5f,  1.0f,  0.0f,  0.0f,  1.0f, 0.0f,

		 //Bottom Face       
		 -0.5f, -0.5f, -0.5f,  0.0f, -1.0f,  0.0f,  0.0f, 1.0f,
		  0.5f, -0.5f, -0.5f,  0.0f, -1.0f,  0.0f,  1.0f, 1.0f,
		  0.5f, -0.5f,  0.5f,  0.0f, -1.0f,  0.0f,  1.0f, 0.0f,
		  0.5f, -0.5f,  0.5f,  0.0f, -1.0f,  0.0f,  1.0f, 0.0f,
		 -0.5f, -0.5f,  0.5f,  0.0f, -1.0f,  0.0f,  0.0f, 0.0f,
		 -0.5f, -0.5f, -0.5f,  0.0f, -1.0f,  0.0f,  0.0f, 1.0f,

		 //Top Face           
		 -0.5f,  0.5f, -0.5f,  0.0f,  1.0f,  0.0f,  0.0f, 1.0f,
		  0.5f,  0.5f, -0.5f,  0.0f,  1.0f,  0.0f,  1.0f, 1.0f,
		  0.5f,  0.5f,  0.5f,  0.0f,  1.0f,  0.0f,  1.0f, 0.0f,
		  0.5f,  0.5f,  0.5f,  0.0f,  1.0f,  0.0f,  1.0f, 0.0f,
		 -0.5f,  0.5f,  0.5f,  0.0f,  1.0f,  0.0f,  0.0f, 0.0f,
		 -0.5f,  0.5f, -0.5f,  0.0f,  1.0f,  0.0f,  0.0f, 1.0f
	};


	// Creates the Vertex Attribute Pointer for the screen coordinates
	const GLuint floatsPerVertex = 3;
	const GLuint floatsPerNormal = 3;
	const GLuint floatsPerUV = 2;

	// Number of vertices per object
	mesh.nVertices = sizeof(bookPages) / (sizeof(bookPages[0]) * (floatsPerVertex + floatsPerNormal + floatsPerUV));
	mesh.nBookCoverVertices = sizeof(bookCover) / (sizeof(bookCover[0]) * floatsPerVertex + floatsPerNormal + floatsPerUV);
	mesh.nStickyPlaneVertices = sizeof(stickyPadsPlane) / sizeof(stickyPadsPlane[0]) * (floatsPerVertex + floatsPerNormal + floatsPerUV);
	mesh.nStickyVertices = sizeof(stickyPads) / sizeof(stickyPads[0]) * (floatsPerVertex + floatsPerNormal + floatsPerUV);
	mesh.nHighlighterVertices = sizeof(cylinder) / sizeof(cylinder[0]) * (floatsPerVertex + floatsPerNormal + floatsPerUV);
	mesh.nPaperWeightVertices = sizeof(paperWeight) / sizeof(paperWeight[0]) * (floatsPerVertex + floatsPerNormal + floatsPerUV);
	mesh.nPlaneVertices = sizeof(plane) / sizeof(plane[0]) * (floatsPerVertex + floatsPerNormal + floatsPerUV);
	mesh.nCubeVertices = sizeof(cubeVerts) / sizeof(cubeVerts[0]) * (floatsPerVertex + floatsPerNormal + floatsPerUV);

	// Strides between vertex coordinates
	GLint stride = sizeof(float) * (floatsPerVertex + floatsPerNormal + floatsPerUV);


	// ---- Book Pages ---- //

	glGenVertexArrays(1, &mesh.VAO);		 // Create VAO
	glBindVertexArray(mesh.VAO);			 // Activate VAO
	glGenBuffers(1, &mesh.VBO);				 // Create VBO
	glBindBuffer(GL_ARRAY_BUFFER, mesh.VBO); // Activates the buffer
	glBufferData(GL_ARRAY_BUFFER, sizeof(bookPages), bookPages, GL_STATIC_DRAW); // Sends vertex or coordinate data to the GPU


	// Create Vertex Attribute Pointers
	glVertexAttribPointer(0, floatsPerVertex, GL_FLOAT, GL_FALSE, stride, 0);
	glEnableVertexAttribArray(0);
	glVertexAttribPointer(1, floatsPerNormal, GL_FLOAT, GL_FALSE, stride, (void*)(sizeof(float) * floatsPerVertex));
	glEnableVertexAttribArray(1);
	glVertexAttribPointer(2, floatsPerUV, GL_FLOAT, GL_FALSE, stride, (void*)(sizeof(float) * (floatsPerVertex + floatsPerNormal)));
	glEnableVertexAttribArray(2);

	// unbind oVAO
	glBindVertexArray(0);


	// ---- Book Cover ----//
	glGenVertexArrays(1, &mesh.bcVAO);			// generate VAO for Book Cover
	glBindVertexArray(mesh.bcVAO);				// bind VAO
	glGenBuffers(1, &mesh.bcVBO);				// generate VBO
	glBindBuffer(GL_ARRAY_BUFFER, mesh.bcVBO);	// Activates the buffer
	glBufferData(GL_ARRAY_BUFFER, sizeof(bookCover), bookCover, GL_STATIC_DRAW);

	// Creat Vertex Attribute Pointer for Book Cover
	glVertexAttribPointer(0, floatsPerVertex, GL_FLOAT, GL_FALSE, stride, 0);
	glEnableVertexAttribArray(0);
	glVertexAttribPointer(1, floatsPerNormal, GL_FLOAT, GL_FALSE, stride, (void*)(sizeof(float) * floatsPerVertex));
	glEnableVertexAttribArray(1);
	glVertexAttribPointer(2, floatsPerUV, GL_FLOAT, GL_FALSE, stride, (void*)(sizeof(float) * (floatsPerVertex + floatsPerNormal)));
	glEnableVertexAttribArray(2);

	// unbind oVAO
	glBindVertexArray(0);

	// ---- Sticky Pads Plane ---- //
	glGenVertexArrays(1, &mesh.spVAO);			// Create VAO
	glBindVertexArray(mesh.spVAO);				// Activate VAO
	glGenBuffers(1, &mesh.spVBO);				// Create VBO
	glBindBuffer(GL_ARRAY_BUFFER, mesh.spVBO);	// Activates the buffer
	glBufferData(GL_ARRAY_BUFFER, sizeof(stickyPadsPlane), stickyPadsPlane, GL_STATIC_DRAW); // Sends vertex or coordinate data to the GPU


	// Create Vertex Attribute Pointers
	glVertexAttribPointer(0, floatsPerVertex, GL_FLOAT, GL_FALSE, stride, 0);
	glEnableVertexAttribArray(0);
	glVertexAttribPointer(1, floatsPerNormal, GL_FLOAT, GL_FALSE, stride, (void*)(sizeof(float) * floatsPerVertex));
	glEnableVertexAttribArray(1);
	glVertexAttribPointer(2, floatsPerUV, GL_FLOAT, GL_FALSE, stride, (void*)(sizeof(float) * (floatsPerVertex + floatsPerNormal)));
	glEnableVertexAttribArray(2);

	// unbind oVAO
	glBindVertexArray(0);

	// ---- Sticky Pads ---- //
	glGenVertexArrays(1, &mesh.sVAO);			 // Create VAO
	glBindVertexArray(mesh.sVAO);				 // Activate VAO
	glGenBuffers(1, &mesh.sVBO);				// Create VBO
	glBindBuffer(GL_ARRAY_BUFFER, mesh.sVBO);	// Activates the buffer
	glBufferData(GL_ARRAY_BUFFER, sizeof(stickyPads), stickyPads, GL_STATIC_DRAW); // Sends vertex or coordinate data to the GPU


	// Create Vertex Attribute Pointers
	glVertexAttribPointer(0, floatsPerVertex, GL_FLOAT, GL_FALSE, stride, 0);
	glEnableVertexAttribArray(0);
	glVertexAttribPointer(1, floatsPerNormal, GL_FLOAT, GL_FALSE, stride, (void*)(sizeof(float) * floatsPerVertex));
	glEnableVertexAttribArray(1);
	glVertexAttribPointer(2, floatsPerUV, GL_FLOAT, GL_FALSE, stride, (void*)(sizeof(float) * (floatsPerVertex + floatsPerNormal)));
	glEnableVertexAttribArray(2);

	// unbind oVAO
	glBindVertexArray(0);

	// ---- Highlighter ---- //
	glGenVertexArrays(1, &mesh.hVAO);			 // Create VAO
	glBindVertexArray(mesh.hVAO);				 // Activate VAO
	glGenBuffers(1, &mesh.hVBO);				 // Create VBO
	glBindBuffer(GL_ARRAY_BUFFER, mesh.hVBO);	 // Activates the buffer
	glBufferData(GL_ARRAY_BUFFER, sizeof(cylinder), cylinder, GL_STATIC_DRAW); // Sends vertex or coordinate data to the GPU


	// Create Vertex Attribute Pointers
	glVertexAttribPointer(0, floatsPerVertex, GL_FLOAT, GL_FALSE, stride, 0);
	glEnableVertexAttribArray(0);
	glVertexAttribPointer(1, floatsPerNormal, GL_FLOAT, GL_FALSE, stride, (void*)(sizeof(float)* floatsPerVertex));
	glEnableVertexAttribArray(1);
	glVertexAttribPointer(2, floatsPerUV, GL_FLOAT, GL_FALSE, stride, (void*)(sizeof(float)* (floatsPerVertex + floatsPerNormal)));
	glEnableVertexAttribArray(2);

	// unbind oVAO
	glBindVertexArray(0);

	// ---- Ppaer Weight ---- //
	glGenVertexArrays(1, &mesh.pwVAO);			// generate VAO for Book Cover
	glBindVertexArray(mesh.pwVAO);				// bind VAO
	glGenBuffers(1, &mesh.pwVBO);				// generate VBO
	glBindBuffer(GL_ARRAY_BUFFER, mesh.pwVBO);	// Activates the buffer
	glBufferData(GL_ARRAY_BUFFER, sizeof(paperWeight), paperWeight, GL_STATIC_DRAW);

	// Creat Vertex Attribute Pointer for Book Cover
	glVertexAttribPointer(0, floatsPerVertex, GL_FLOAT, GL_FALSE, stride, 0);
	glEnableVertexAttribArray(0);
	glVertexAttribPointer(1, floatsPerNormal, GL_FLOAT, GL_FALSE, stride, (void*)(sizeof(float)* floatsPerVertex));
	glEnableVertexAttribArray(1);
	glVertexAttribPointer(2, floatsPerUV, GL_FLOAT, GL_FALSE, stride, (void*)(sizeof(float)* (floatsPerVertex + floatsPerNormal)));
	glEnableVertexAttribArray(2);

	// ---- Desk Plane ---- //
	glGenVertexArrays(1, &mesh.pVAO);			// generate VAO for plane
	glBindVertexArray(mesh.pVAO);				// bind VAO
	glGenBuffers(1, &mesh.pVBO);				// generate VBO 
	glBindBuffer(GL_ARRAY_BUFFER, mesh.pVBO);	// Activates the buffer
	glBufferData(GL_ARRAY_BUFFER, sizeof(plane), plane, GL_STATIC_DRAW);

	// Creat Vertex Attribute Pointer for Plane
	glVertexAttribPointer(0, floatsPerVertex, GL_FLOAT, GL_FALSE, stride, 0);
	glEnableVertexAttribArray(0);
	glVertexAttribPointer(1, floatsPerNormal, GL_FLOAT, GL_FALSE, stride, (void*)(sizeof(float) * floatsPerVertex));
	glEnableVertexAttribArray(1);
	glVertexAttribPointer(2, floatsPerUV, GL_FLOAT, GL_FALSE, stride, (void*)(sizeof(float) * (floatsPerVertex + floatsPerNormal)));
	glEnableVertexAttribArray(2);

	glBindVertexArray(0);

	// ---- Light Cubes ---- //
	// Gen VAO for light cubes
	glGenVertexArrays(1, &mesh.cVAO);			// generate VAO
	glBindVertexArray(mesh.cVAO);				// bind VAO
	glGenBuffers(1, &mesh.cVBO);				// gen VBO
	glBindBuffer(GL_ARRAY_BUFFER, mesh.cVBO);	// Activates the buffer
	glBufferData(GL_ARRAY_BUFFER, sizeof(cubeVerts), cubeVerts, GL_STATIC_DRAW); // Sends vertex or coordinate data to the GPU

	// Create Vertex Attribute Pointers for light
	glVertexAttribPointer(0, floatsPerVertex, GL_FLOAT, GL_FALSE, stride, 0);
	glEnableVertexAttribArray(0);
	glVertexAttribPointer(1, floatsPerNormal, GL_FLOAT, GL_FALSE, stride, (void*)(sizeof(float) * floatsPerVertex));
	glEnableVertexAttribArray(1);
	glVertexAttribPointer(2, floatsPerUV, GL_FLOAT, GL_FALSE, stride, (void*)(sizeof(float) * (floatsPerVertex + floatsPerNormal)));
	glEnableVertexAttribArray(2);

	glBindVertexArray(0);


}

bool createTexture(const char* filename, GLuint& textureId)
{
	int width, height, channels;
	unsigned char* image = stbi_load(filename, &width, &height, &channels, 0);
	if (image)
	{
		flipImageVertically(image, width, height, channels);

		glGenTextures(1, &textureId);
		glBindTexture(GL_TEXTURE_2D, textureId);

		// Set the texture wrapping parameters.
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
		// Set texture filtering parameters.
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

		if (channels == 3)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB8, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);
		else if (channels == 4)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, image);
		else
		{
			cout << "Not implemented to handle image with " << channels << " channels" << endl;
			return false;
		}

		glGenerateMipmap(GL_TEXTURE_2D);

		stbi_image_free(image);
		glBindTexture(GL_TEXTURE_2D, 0); // Unbind the texture.

		return true;
	}

	// Error loading the image
	return false;
}

/* Releases texture  /
/  ---------------- */
void destroyTexture(GLuint textureId)
{
	glGenTextures(1, &textureId);
}


/* Releases mesh  /
/  ------------- */
void destroyMesh(GLMesh& mesh) {
	glDeleteVertexArrays(1, &mesh.VAO);
	glDeleteBuffers(1, &mesh.VBO);
}


/* Creates program for shaders  /
/  --------------------------- */
bool createShaderProgram(const char* vertexShaderSource, const char* fragmentShaderSource, GLuint& programId) {

	// Error Reporting 
	int success = 0;
	char infoLog[512];

	// Create  shader program 
	programId = glCreateProgram();

	// Create vertex and shader objects and retrieve source.
	GLuint vertexShader = glCreateShader(GL_VERTEX_SHADER);
	GLuint fragmentShader = glCreateShader(GL_FRAGMENT_SHADER);
	glShaderSource(vertexShader, 1, &vertexShaderSource, NULL);
	glShaderSource(fragmentShader, 1, &fragmentShaderSource, NULL);

	// Compile shaders and print any errors 
	glCompileShader(vertexShader);
	glGetShaderiv(vertexShader, GL_COMPILE_STATUS, &success);
	if (!success) {
		glGetShaderInfoLog(vertexShader, 512, NULL, infoLog);
		cout << "ERROR::SHADER::VERTEX::COMPILATION_FAILED\n" << infoLog << endl;

		return false;
	}

	glCompileShader(fragmentShader);
	glGetShaderiv(fragmentShader, GL_COMPILE_STATUS, &success);
	if (!success) {
		glGetShaderInfoLog(fragmentShader, sizeof(infoLog), NULL, infoLog);
		cout << "ERROR::SHADER:FRAGMENT:COMPILATION_FAILED\n" << infoLog << endl;

		return false;
	}

	// Attatch compiled shaders and link the program then print errors
	glAttachShader(programId, vertexShader);
	glAttachShader(programId, fragmentShader);
	glLinkProgram(programId);

	glGetProgramiv(programId, GL_LINK_STATUS, &success);
	if (!success) {
		glGetProgramInfoLog(programId, sizeof(infoLog), NULL, infoLog);
		cout << "ERROR::SHADER::PROGRAM::LINKING_FAILED\n" << infoLog << endl;

		return false;
	}

	glUseProgram(programId);

	return true;
}


/* Function to release shader program  /
/  ---------------------------------- */
void destroyShaderProgram(GLuint programId) {
	glDeleteProgram(programId);
}


/* Main Function  /
/  ------------- */
int main(int argc, char* argv[]) {

	if (!initialize(argc, argv, &gWindow))
		return EXIT_FAILURE;

	// Create the mesh
	createMesh(gMesh); // Calls the function to create the Vertex Buffer Object


	// Create the shader program
	if (!createShaderProgram(vertexShaderSource, fragmentShaderSource, gProgramId))
		return EXIT_FAILURE;
	if (!createShaderProgram(lampVertexShaderSource, lampFragmentShaderSource, gLampProgramId))
		return EXIT_FAILURE;
	if (!createShaderProgram(vertexShaderSource, fragmentShaderSource, gPlaneId))
		return EXIT_FAILURE;
	if (!createShaderProgram(fillVertexShaderSource, fillFragmentShaderSource, gFillProgramId))
		return EXIT_FAILURE;

	// Load textures
	const char* bsTexFilename = "images/bookSide.jpg";
	if (!createTexture(bsTexFilename, bpTextureId))
	{
		cout << "Failed to load texture " << bsTexFilename << endl;
		return EXIT_FAILURE;
	}
	const char* bcTexFilename = "images/bookCover.jpg";
	if (!createTexture(bcTexFilename, bcTextureId))
	{
		cout << "Failed to load texture " << bcTexFilename << endl;
		return EXIT_FAILURE;
	}
	const char* pTexFilename = "images/wood.jpg";
	if (!createTexture(pTexFilename, pTextureId))
	{
		cout << "Failed to load texture " << pTexFilename << endl;
		return EXIT_FAILURE;
	}
	const char* spTexFilename = "images/PinkPaper.jpg";
	if (!createTexture(spTexFilename, spTextureId))
	{
		cout << "Failed to load texture " << spTexFilename << endl;
		return EXIT_FAILURE;
	}
	const char* sTexFilename = "images/Blue.jpg";
	if (!createTexture(sTexFilename, sTextureId))
	{
		cout << "Failed to load texture " << sTexFilename << endl;
		return EXIT_FAILURE;
	}
	const char* hTexFilename = "images/WhitePlastic.jpg";
	if (!createTexture(hTexFilename, hTextureId))
	{
		cout << "Failed to load texture " << hTexFilename << endl;
		return EXIT_FAILURE;
	}
	const char* h2TexFilename = "images/Orange Plastic.jpg";
	if (!createTexture(h2TexFilename, h2TextureId))
	{
		cout << "Failed to load texture " << h2TexFilename << endl;
		return EXIT_FAILURE;
	}
	const char* pwTexFilename = "images/Silver.jpg";
	if (!createTexture(pwTexFilename, pwTextureId))
	{
		cout << "Failed to load texture " << pwTexFilename << endl;
		return EXIT_FAILURE;
	}


	// tell opengl for each sampler to which texture unit it belongs to (only has to be done once)
	glUseProgram(gProgramId);
	// We set the texture as texture unit 0
	glUniform1i(glGetUniformLocation(gProgramId, "uTexture"), 0);

	// Sets the background color of the window
	glClearColor(0.0f, 0.0f, 0.0f, 1.0f);

	// render loop
	while (!glfwWindowShouldClose(gWindow))
	{
		// per-frame timing
		float currentFrame = glfwGetTime();
		gDeltaTime = currentFrame - gLastFrame;
		gLastFrame = currentFrame;

		// input
		processInput(gWindow);

		// Render this frame
		render();

		glfwPollEvents();
	}

	// Release mesh data
	destroyMesh(gMesh);

	// Release shader program
	destroyShaderProgram(gProgramId);
	destroyShaderProgram(gLampProgramId);
	destroyShaderProgram(gFillProgramId);

	destroyTexture(bcTextureId);
	destroyTexture(bpTextureId);
	destroyTexture(pwTextureId);
	destroyTexture(hTextureId);
	destroyTexture(h2TextureId);
	destroyTexture(pTextureId);
	destroyTexture(sTextureId);
	destroyTexture(spTextureId);

	exit(EXIT_SUCCESS);
}
